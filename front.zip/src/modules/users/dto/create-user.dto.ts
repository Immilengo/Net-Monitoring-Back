export interface CreateUserDto {
  fullName: string;
  email: string;
  password: string;
  phone?: string;
  statusId?: string;
  roleName?: string;
}
